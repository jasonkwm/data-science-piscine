## Build

```
// Mac/Linux
python3 -m pip install --upgrade build

// Windows
py -m pip install --upgrade build
```

## Install

```
pip install ./dist/ft_package-0.0.1.tar.gz
// or
pip install ./dist/ft_package-0.0.1-py3-none-any.whl
```
